#include <string.h>
#include<stdio.h>
#include "uart_int.h"

#include "delay.h"

#include "lcd.h"




extern char buff[200];

extern unsigned char i;


void esp01_connectAP(void)

{

        CmdLCD(0x01);

        CmdLCD(0x80);

        StrLCD("AT");

        delay_ms(1000);

        UART0_Str("AT\r\n");

        i=0;memset(buff,'\0',200);

        while(i<4);

        delay_ms(500);

        buff[i] = '\0';

        CmdLCD(0x01);

        CmdLCD(0x80);

        StrLCD(buff);

        delay_ms(2000);

        if(strstr(buff,"OK"))
        {

                CmdLCD(0xC0);

                StrLCD("OK");

                delay_ms(1000);

        }

        else

        {

                CmdLCD(0xC0);

                StrLCD("ERROR");

                delay_ms(1000);

                return;

        }





        CmdLCD(0x01);

        CmdLCD(0x80);

        StrLCD("ATE0");

        delay_ms(1000);

        UART0_Str("ATE0\r\n");

        i=0;
        memset(buff,'\0',200);

        while(i<4);

        delay_ms(500);

        buff[i] = '\0';

        CmdLCD(0x01);

        CmdLCD(0x80);

        StrLCD(buff);

        delay_ms(2000);

        if(strstr(buff,"OK"))

        {

                CmdLCD(0xC0);

                StrLCD("OK");

                delay_ms(1000);

        }

        else

        {

                CmdLCD(0xC0);

                StrLCD("ERROR");

                delay_ms(1000);

                return;

        }





        CmdLCD(0x01);

        CmdLCD(0x80);

        StrLCD("AT+CIPMUX");

        delay_ms(1000);

        UART0_Str("AT+CIPMUX=0\r\n");

        i=0;memset(buff,'\0',200);

        while(i<4);

        delay_ms(500);

        buff[i] = '\0';

        CmdLCD(0x01);

        CmdLCD(0x80);

        StrLCD(buff);

        delay_ms(2000);

        if(strstr(buff,"OK"))

        {

                CmdLCD(0xC0);

                StrLCD("OK");

                delay_ms(1000);

        }

        else

        {

                CmdLCD(0xC0);

                StrLCD("ERROR");

                delay_ms(1000);

                return;

        }



        CmdLCD(0x01);

        CmdLCD(0x80);

        StrLCD("AT+CWQAP");

        delay_ms(1000);

        UART0_Str("AT+CWQAP\r\n");

        i=0;memset(buff,'\0',200);

        while(i<4);

        delay_ms(1500);

        buff[i] = '\0';

        CmdLCD(0x01);

        CmdLCD(0x80);

        StrLCD(buff);

        delay_ms(2000);

        if(strstr(buff,"OK"))

        {

                CmdLCD(0xC0);

                StrLCD("OK");

                delay_ms(1000);

        }

        else

        {

                CmdLCD(0xC0);

                StrLCD("ERROR");

                delay_ms(1000);

                return;

        }







        CmdLCD(0x01);

        CmdLCD(0x80);

        StrLCD("AT+CWJAP");

        delay_ms(1000);

        //need to change the wifi network name and password

        UART0_Str("AT+CWJAP=\"Hari\",\"Hari@2526\"\r\n");

        i=0;memset(buff,'\0',200);

        while(i<4);

        delay_ms(2500);

        buff[i] = '\0';

        CmdLCD(0x01);

        CmdLCD(0x80);

        StrLCD(buff);

        delay_ms(2000);

        if(strstr(buff,"WIFI CONNECTED"))

        {

                CmdLCD(0xC0);

                StrLCD("OK");

                delay_ms(1000);

        }

        else

        {

                CmdLCD(0xC0);

                StrLCD("ERROR");

                delay_ms(1000);

                return;

        }



}



void esp01_sendToThingspeak(char *val)
{
    char cmd[60];
    int len;


    CmdLCD(0x01);
    CmdLCD(0x80);
    StrLCD("AT+CIPSTART");
    delay_ms(1000);
    UART0_Str("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n");

    i = 0;
    memset(buff, '\0', 200);
    while(i < 5);
    delay_ms(2500);
    buff[i] = '\0';

    CmdLCD(0x01);
    CmdLCD(0x80);
    StrLCD(buff);
    delay_ms(2000);

    if(strstr(buff, "CONNECT") || strstr(buff, "ALREADY CONNECTED"))
    {
        CmdLCD(0xC0);
        StrLCD("OK");
        delay_ms(1000);


        CmdLCD(0x01);
        CmdLCD(0x80);
        StrLCD("AT+CIPSEND");

        delay_ms(1000);


        len = strlen("GET /update?api_key=IQSBGC0WQDGQCVWI&field1=") + strlen(val) + strlen("\r\n\r\n");
        sprintf(cmd, "AT+CIPSEND=%d\r\n", len);
        UART0_Str(cmd);

        i = 0;
        memset(buff, '\0', 200);
        while(!strstr(buff, ">"));  // Wait for '>' prompt to send data


        UART0_Str("GET /update?api_key=IQSBGC0WQDGQCVWI&field1=");
        UART0_Str(val);
        UART0_Str("\r\n\r\n");


        i = 0;
        memset(buff, '\0', 200);
        delay_ms(5000);
        buff[i] = '\0';

        CmdLCD(0x01);
        CmdLCD(0x80);
        StrLCD(buff);
        delay_ms(2000);

        if(strstr(buff, "SEND OK"))
        {
            CmdLCD(0x01);
            StrLCD("DATA UPDATED");
            delay_ms(1000);
        }
        else
        {
            CmdLCD(0x01);
            StrLCD("DATA NOT UPDATED");
            delay_ms(1000);
        }
    }
    else
    {
        CmdLCD(0xC0);
        StrLCD("ERROR");
        delay_ms(1000);
        return;
    }
}
void esp01_sendToThingspeak1(char *val)
{
    char cmd[60];
    int len;


    CmdLCD(0x01);
    CmdLCD(0x80);
    StrLCD("AT+CIPSTART");
    delay_ms(1000);
    UART0_Str("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n");

    i = 0;
    memset(buff, '\0', 200);
    while(i < 5);
    delay_ms(2500);
    buff[i] = '\0';

    CmdLCD(0x01);
    CmdLCD(0x80);
    StrLCD(buff);
    delay_ms(2000);

    if(strstr(buff, "CONNECT") || strstr(buff, "ALREADY CONNECTED"))
    {
        CmdLCD(0xC0);
        StrLCD("OK");
        delay_ms(1000);


        CmdLCD(0x01);
        CmdLCD(0x80);
        StrLCD("AT+CIPSEND");

        delay_ms(1000);


        len = strlen("GET /update?api_key=IQSBGC0WQDGQCVWI&field2=") + strlen(val) + strlen("\r\n\r\n");
        sprintf(cmd, "AT+CIPSEND=%d\r\n", len);
        UART0_Str(cmd);

        i = 0;
        memset(buff, '\0', 200);
        while(!strstr(buff, ">"));


        UART0_Str("GET /update?api_key=IQSBGC0WQDGQCVWI&field2=");
        UART0_Str(val);
        UART0_Str("\r\n\r\n");


        i = 0;
        memset(buff, '\0', 200);
        delay_ms(5000);
        buff[i] = '\0';

        CmdLCD(0x01);
        CmdLCD(0x80);
        StrLCD(buff);
        delay_ms(2000);

        if(strstr(buff, "SEND OK"))
        {
            CmdLCD(0x01);
            StrLCD("DATA UPDATED");
            delay_ms(1000);
        }
        else
        {
            CmdLCD(0x01);
            StrLCD("DATA NOT UPDATED");
            delay_ms(1000);
        }
    }
    else
    {
        CmdLCD(0xC0);
        StrLCD("ERROR");
        delay_ms(1000);
        return;
    }
}