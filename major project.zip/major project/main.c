#include <lpc21xx.h>
#include <stdio.h>
#include "lcd.h"
#include "lcd_defines.h"
#include "keypad.h"
#include "rtc.h"
#include "rtc_defines.h"
#include "delay.h"
#include "esp01.h"
#include "adc.h"
#include "adc_defines.h"
#include "UART_INT.h"

#define MQ2_PIN (1<<20)
#define SW 3
#define EINT1_PIN      3
#define EINT1_VIC_CHNO 15

int last_sent_min = 0;
int initial_offset = 0;
int temperature, gas_status;
int hour = 12, min = 0, sec = 0, date = 1, month = 1, year = 2025, day = 0;
char gas_str[4];
char temp_str[4];
u8 key;
s32 var;
static int prev_gas_status = -1;

void Enable_EINT1(void);
void show_main_menu(void);
void restart(void);
void edit_RTC(void);
void eint1_isr(void) __irq;
u32 GetHour(void);
u32 GetMin(void);
u32 GetSec(void);
u32 GetDate(void);
u32 GetDay(void);
u32 GetMonth(void);
u32 GetYear(void);

void show_main_menu(void) {
    CmdLCD(0x01);
    SetCursor(1, 0);
    StrLCD("1. Edit RTC");
    SetCursor(2, 0);
    StrLCD("2. Restart");
    SetCursor(3, 0);
    StrLCD("3. Exit");
    key = KeyDetect();
    if (key == '1') {
        edit_RTC();
        CmdLCD(0x01);
    } else if (key == '2') {
        restart();
    } else if (key == '3') {
        return;
    } else {
        StrLCD("Invalid Key");
        delay_ms(500);
        show_main_menu();
    }
}

void restart(void) {
    hour = 12; min = 0; sec = 0;
    date = 1; month = 1; year = 2025; day = 0;

    SetRTCTime(hour, min, sec);
    SetRTCDate(date, month, year);
    SetRTCDay(day);
    last_sent_min = min;
    initial_offset = 0;

    CmdLCD(0x01);
    SetCursor(1, 0);
    StrLCD("RTC Restarted");
    delay_ms(1000);
    CmdLCD(0x01);
}

void eint1_isr(void) __irq {
    show_main_menu();
    delay_ms(2000);
    CmdLCD(0x01);
    EXTINT = 1 << 1;
    VICVectAddr = 0;
}

void Enable_EINT1(void) {
    PINSEL0 |= 0x000000C0; // P0.3 as EINT1
    VICIntEnable = 1 << EINT1_VIC_CHNO;
    VICVectCntl1 = (1 << 5) | EINT1_VIC_CHNO;
    VICVectAddr1 = (u32)eint1_isr;
    EXTMODE = 1 << 1;
}

void edit_RTC(void) {
    unsigned char key;
    while (1) {
        CmdLCD(0x01);
        SetCursor(1, 0);
        StrLCD("1.H 2.M 3.S 4.D");
        SetCursor(2, 0);
        StrLCD("5.d 6.m 7.y 8.E");
        key = KeyDetect();
        switch (key) {
            case '1': hour = GetHour(); break;
            case '2': min = GetMin(); break;
            case '3': sec = GetSec(); break;
            case '4': date = GetDate(); break;
            case '5': day = GetDay(); break;
            case '6': month = GetMonth(); break;
            case '7': year = GetYear(); break;
            case '8':
                GetRTCTime(&hour, &min, &sec);
                initial_offset = min % 3;
                last_sent_min = 99;
                CmdLCD(0x01);
                StrLCD("Returning...");
                delay_ms(1000);
                CmdLCD(0x01);
                return;
            default:
                StrLCD("Invalid Key");
                delay_ms(1000);
                CmdLCD(0x01);
        }
        SetRTCTime(hour, min, sec);
        SetRTCDate(date, month, year);
        SetRTCDay(day);
    }
}

u32 GetHour(void)
{
        CmdLCD(0x01);
    hour: StrLCD("Enter hour:");
    var = ReadNum();
    if (var <= 12)
                return var;
    CmdLCD(0x01); StrLCD("Invalid hour"); delay_ms(500); CmdLCD(0x01); goto hour;
}

u32 GetMin(void) {
    CmdLCD(0x01);
        minute: StrLCD("Enter minute:");
    var = ReadNum();
    if (var <= 59) return var;
    CmdLCD(0x01); StrLCD("Invalid minute"); delay_ms(500); CmdLCD(0x01); goto minute;
}

u32 GetSec(void) {
    CmdLCD(0x01);
        second: StrLCD("Enter second:");
    var = ReadNum();
    if (var <= 59) return var;
    CmdLCD(0x01); StrLCD("Invalid second"); delay_ms(500); CmdLCD(0x01); goto second;
}

u32 GetDate(void) {
    CmdLCD(0x01);
        date: StrLCD("Enter date:");
    var = ReadNum();
    if (var > 0 && var <= 31) return var;
    CmdLCD(0x01); StrLCD("Invalid date"); delay_ms(500); CmdLCD(0x01); goto date;
}

u32 GetDay(void) {
    CmdLCD(0x01);
        day: StrLCD("Enter day : ");
    var = ReadNum();
    if (var >= 0 && var <= 6) return var;
    CmdLCD(0X01); StrLCD("Invalid day"); delay_ms(500); CmdLCD(0x01); goto day;
}

u32 GetMonth(void) {
    CmdLCD(0x01);
        month: StrLCD("Enter month :");
    var = ReadNum();
    if (var >= 1 && var <= 12) return var;
    CmdLCD(0x01); StrLCD("Invalid month"); delay_ms(500); CmdLCD(0x01); goto month;
}

u32 GetYear(void) {
    CmdLCD(0x01);
        StrLCD("Enter year:");
    var = ReadNum();
    return var;
}

int main() {
    InitLCD();
    InitUART0();
    esp01_connectAP();
    CmdLCD(0x01);

    RTC_Init();
    Init_ADC();
    Init_KPM();
    Enable_EINT1();

    StrLCD("  MAJOR PROJECT  ");
    delay_ms(2000);
    CmdLCD(0x01);

    GetRTCTime(&hour, &min, &sec);
    initial_offset = min % 3;
    last_sent_min = 99;



    while (1) {
        GetRTCTime(&hour, &min, &sec);
        DisplayRTCTime(hour, min, sec);
        GetRTCDate(&date, &month, &year);
        DisplayRTCDate(date, month, year);

        temperature = (int)(Read_ADC(CH1) * 100);
        SetCursor(1, 10);
        StrLCD("T:");
        U32LCD(temperature);
        CharLCD(0xDF);
        CharLCD('C');

       /* gas_status = (IOPIN0 & MQ2_PIN) ?  0: 1;
        SetCursor(2, 11);
        StrLCD("G:");

        if (gas_status == 1) {
            StrLCD("L");
            if (prev_gas_status != 1) {
                sprintf(gas_str, "1");
                esp01_sendToThingspeak1(gas_str);
                prev_gas_status = 1;
                                CmdLCD(0x01);
            }
        } else {
            StrLCD("S");
            if (prev_gas_status != 0) {
                sprintf(gas_str, "0");
                esp01_sendToThingspeak1(gas_str);
                prev_gas_status = 0;
                                CmdLCD(0x01);
            }
        }*/
                gas_status = (IOPIN0 & MQ2_PIN) ? 0 : 1;

                SetCursor(2, 11);
                StrLCD("G: ");

                if (gas_status == 1) {
                        CharLCD('L');
        if (prev_gas_status != 1) {
                sprintf(gas_str, "1");
                esp01_sendToThingspeak1(gas_str);
                prev_gas_status = 1;
                CmdLCD(0x01);
        }
                } else {
                CharLCD('S');
                if (prev_gas_status != 0) {
                                sprintf(gas_str, "0");
                                esp01_sendToThingspeak1(gas_str);
                                prev_gas_status = 0;
                                CmdLCD(0x01);
    }
}


        if (((min - initial_offset + 60) % 3 == 0) && sec == 0 && min != last_sent_min) {
            sprintf(temp_str, "%d", temperature);
            esp01_sendToThingspeak(temp_str);
            last_sent_min = min;
            CmdLCD(0x01);
        }

        delay_s(1);
    }
}